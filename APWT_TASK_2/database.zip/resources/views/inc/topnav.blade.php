<a class="btn btn-primary" href="{{route('login')}}">Login</a>
<a class="btn btn-primary" href="{{route('registration')}}">Registration</a>
<a class="btn btn-primary" href="{{route('contact')}}">Contact Us</a>