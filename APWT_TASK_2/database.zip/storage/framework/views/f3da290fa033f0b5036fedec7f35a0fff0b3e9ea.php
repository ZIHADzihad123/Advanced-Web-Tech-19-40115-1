<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    </head>
    <body>
        <div class="container">
            <?php echo $__env->make('inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        
    </body>
</html><?php /**PATH C:\xampp\htdocs\Advanced Web Technology\CLASS TASKS\AWT MID TASKS\APWT_TASK_2\resources\views/layouts/app.blade.php ENDPATH**/ ?>