<a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
<a class="btn btn-primary" href="<?php echo e(route('registration')); ?>">Registration</a>
<a class="btn btn-primary" href="<?php echo e(route('contact')); ?>">Contact Us</a><?php /**PATH C:\xampp\htdocs\Advanced Web Technology\CLASS TASKS\AWT MID TASKS\APWT_TASK_2\resources\views/inc/topnav.blade.php ENDPATH**/ ?>